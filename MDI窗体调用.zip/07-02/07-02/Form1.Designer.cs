﻿namespace _07_02
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.打开子窗体ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开子窗体2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.打开子窗体2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1,
            this.打开子窗体ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(366, 31);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 27);
            this.toolStripTextBox1.Text = "文件";
            this.toolStripTextBox1.Click += new System.EventHandler(this.toolStripTextBox1_Click);
            // 
            // 打开子窗体ToolStripMenuItem
            // 
            this.打开子窗体ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开子窗体2ToolStripMenuItem,
            this.打开子窗体2ToolStripMenuItem1});
            this.打开子窗体ToolStripMenuItem.Name = "打开子窗体ToolStripMenuItem";
            this.打开子窗体ToolStripMenuItem.Size = new System.Drawing.Size(96, 27);
            this.打开子窗体ToolStripMenuItem.Text = "打开子窗体";
            // 
            // 打开子窗体2ToolStripMenuItem
            // 
            this.打开子窗体2ToolStripMenuItem.Name = "打开子窗体2ToolStripMenuItem";
            this.打开子窗体2ToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.打开子窗体2ToolStripMenuItem.Text = "打开子窗体1";
            this.打开子窗体2ToolStripMenuItem.Click += new System.EventHandler(this.打开子窗体2ToolStripMenuItem_Click);
            // 
            // 打开子窗体2ToolStripMenuItem1
            // 
            this.打开子窗体2ToolStripMenuItem1.Name = "打开子窗体2ToolStripMenuItem1";
            this.打开子窗体2ToolStripMenuItem1.Size = new System.Drawing.Size(181, 26);
            this.打开子窗体2ToolStripMenuItem1.Text = "打开子窗体2";
            this.打开子窗体2ToolStripMenuItem1.Click += new System.EventHandler(this.打开子窗体2ToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 335);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "父窗体";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem 打开子窗体ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开子窗体2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开子窗体2ToolStripMenuItem1;
    }
}

