﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void 打开子窗体2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frmchild = new Form2();
            frmchild.MdiParent = this;
            frmchild.Show();
        }

        private void 打开子窗体2ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 frmchild = new Form2();
            frmchild.MdiParent = this;
            frmchild.Show();
        }
    }
}
