﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zzz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

public virtual void msg()
        {
            MessageBox.Show("继承窗体实例");
            }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "基窗体";
            msg();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
