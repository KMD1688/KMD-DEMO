﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kmd
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] num=new int[] {3,34,43,2,11,19,30,55,20};
            bool g = false;
            for (int x = 0;x < num.Length;x++)
            {
                if (num[x] % 7 == 0)
                {
                    g = true;
                    break;
                        }
            }
            if (g)
                Console.WriteLine("有");
            else
                Console.WriteLine("无");
            }
        }
    }
