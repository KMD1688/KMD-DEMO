﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kmd
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] score=new int[] { 89,39,100,51,94,65,70};
            Console.Write("不及格的有：");
           for (int i=0;i<7;i++)
            {
                if(score[i]<60)
                Console.Write(score[i]+",");
            }
        }
    }
}
