﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kmd
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            int sum = 0;
            while (x<=10)
            {
                sum += x;
                x++;
            }
            Console.Write("和" + sum);
        }
    }
}
